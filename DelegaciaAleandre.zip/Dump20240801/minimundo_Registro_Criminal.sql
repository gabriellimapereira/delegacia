CREATE DATABASE  IF NOT EXISTS `minimundo` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `minimundo`;
-- MySQL dump 10.13  Distrib 8.0.36, for Linux (x86_64)
--
-- Host: localhost    Database: minimundo
-- ------------------------------------------------------
-- Server version	8.0.37-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Registro_Criminal`
--

DROP TABLE IF EXISTS `Registro_Criminal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Registro_Criminal` (
  `ID_Reg` int NOT NULL,
  `Tipo_Crime` varchar(100) NOT NULL,
  `Pena` varchar(150) NOT NULL,
  `CPF` char(11) NOT NULL,
  `ID_Func` int NOT NULL,
  PRIMARY KEY (`ID_Reg`),
  KEY `CPF` (`CPF`),
  KEY `ID_Func` (`ID_Func`),
  CONSTRAINT `Registro_Criminal_ibfk_1` FOREIGN KEY (`CPF`) REFERENCES `Meliante` (`CPF`),
  CONSTRAINT `Registro_Criminal_ibfk_2` FOREIGN KEY (`ID_Func`) REFERENCES `Escrivao` (`ID_Func`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Registro_Criminal`
--

LOCK TABLES `Registro_Criminal` WRITE;
/*!40000 ALTER TABLE `Registro_Criminal` DISABLE KEYS */;
INSERT INTO `Registro_Criminal` VALUES (1,'Furto','2 anos de reclusão','23456789023',1),(2,'Roubo','4 anos de reclusão','23456789034',2),(3,'Tráfico de drogas','6 anos de reclusão','34567890122',3),(4,'Homicídio','12 anos de reclusão','34567890123',4),(5,'Estelionato','3 anos de reclusão','34567890134',5),(6,'Lesão corporal','1 ano de reclusão','34567890145',1),(7,'Porte ilegal de arma','2 anos de reclusão','45678901233',2),(8,'Lavagem de dinheiro','7 anos de reclusão','45678901234',3),(9,'Sequestro','8 anos de reclusão','45678901245',4),(10,'Corrupção','5 anos de reclusão','45678901256',5);
/*!40000 ALTER TABLE `Registro_Criminal` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-01 15:34:02

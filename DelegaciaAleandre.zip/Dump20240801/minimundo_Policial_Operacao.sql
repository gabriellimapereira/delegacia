CREATE DATABASE  IF NOT EXISTS `minimundo` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `minimundo`;
-- MySQL dump 10.13  Distrib 8.0.36, for Linux (x86_64)
--
-- Host: localhost    Database: minimundo
-- ------------------------------------------------------
-- Server version	8.0.37-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Policial_Operacao`
--

DROP TABLE IF EXISTS `Policial_Operacao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Policial_Operacao` (
  `ID_Op` int NOT NULL,
  `ID_Func` int NOT NULL,
  PRIMARY KEY (`ID_Func`,`ID_Op`),
  KEY `ID_Op` (`ID_Op`),
  CONSTRAINT `Policial_Operacao_ibfk_1` FOREIGN KEY (`ID_Op`) REFERENCES `Operacao` (`ID_Op`),
  CONSTRAINT `Policial_Operacao_ibfk_2` FOREIGN KEY (`ID_Func`) REFERENCES `Policial` (`ID_Func`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Policial_Operacao`
--

LOCK TABLES `Policial_Operacao` WRITE;
/*!40000 ALTER TABLE `Policial_Operacao` DISABLE KEYS */;
INSERT INTO `Policial_Operacao` VALUES (1,11),(1,12),(1,13),(1,14),(1,15),(1,16),(1,17),(1,18),(1,19),(1,20),(2,11),(2,12),(2,13),(2,16),(2,17),(2,18),(2,19),(2,20),(3,11),(3,12),(3,14),(3,15),(3,16),(3,17),(3,18),(3,19),(4,11),(4,13),(4,14),(4,15),(4,16),(4,17),(4,18),(4,19),(4,20),(5,12),(5,13),(5,14),(5,15),(5,16),(5,17),(5,18),(5,19),(5,20),(6,11),(6,12),(6,13),(6,14),(6,15),(6,16),(6,17),(6,18),(7,12),(7,13),(7,14),(7,15),(7,16),(7,17),(7,18),(7,19),(7,20),(8,11),(8,12),(8,14),(8,15),(8,16),(8,17),(8,18),(8,19),(9,12),(9,13),(9,14),(9,16),(9,17),(9,18),(9,19),(9,20),(10,11),(10,12),(10,13),(10,15),(10,16),(10,17),(10,18),(11,11),(11,12),(11,14),(11,15),(11,16),(11,17),(11,18),(11,19),(11,20),(12,12),(12,13),(12,14),(12,15),(12,16),(12,17),(12,18),(13,11),(13,12),(13,13),(13,15),(13,16),(13,17),(13,18),(13,19),(14,11),(14,13),(14,14),(14,15),(14,16),(14,17),(14,18),(14,20),(15,12),(15,13),(15,14),(15,15),(15,16),(15,17),(15,18),(16,11),(16,12),(16,13),(16,14),(16,16),(16,17),(16,18),(17,12),(17,13),(17,15),(17,16),(17,17),(17,18),(17,19),(18,11),(18,12),(18,13),(18,14),(18,15),(18,16),(18,17),(18,18),(19,11),(19,12),(19,13),(19,14),(19,15),(19,16),(19,17),(20,11),(20,12),(20,13),(20,15),(20,16),(20,17),(20,18);
/*!40000 ALTER TABLE `Policial_Operacao` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-01 15:34:02

CREATE DATABASE  IF NOT EXISTS `minimundo` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `minimundo`;
-- MySQL dump 10.13  Distrib 8.0.36, for Linux (x86_64)
--
-- Host: localhost    Database: minimundo
-- ------------------------------------------------------
-- Server version	8.0.37-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Pessoa`
--

DROP TABLE IF EXISTS `Pessoa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Pessoa` (
  `CPF` char(11) NOT NULL,
  `Nome` varchar(100) NOT NULL,
  `Idade` int DEFAULT NULL,
  `Data_Nasc` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`CPF`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Pessoa`
--

LOCK TABLES `Pessoa` WRITE;
/*!40000 ALTER TABLE `Pessoa` DISABLE KEYS */;
INSERT INTO `Pessoa` VALUES ('00028922132','Tanenbaum da Silva',200,'1824-01-01'),('01234567810','Fábio Rodrigues',35,'1988-09-12'),('01234567821','Michele Silva',30,'1993-07-10'),('01234567822','Gustavo Lima',40,'1983-09-15'),('01234567833','Fernanda Souza',31,'1992-03-15'),('01234567899','Eduardo Silva',25,'1998-11-01'),('12345678900','Ana Silva',28,'1996-02-20'),('12345678901','João Silva',34,'1990-07-25'),('12345678912','Tatiane Silva',24,'1999-10-09'),('12345678923','Pedro Costa',38,'1985-08-17'),('12345678924','Simone Oliveira',29,'1994-02-25'),('12345678935','Júlio Costa',26,'1997-05-20'),('12345678971','Paula Fernandes',38,'1985-12-05'),('23456789011','João Oliveira',34,'1989-03-15'),('23456789012','Marcelo Souza',41,'1982-01-13'),('23456789023','Victor Fernandes',39,'1984-11-15'),('23456789034','Eliane Martins',29,'1994-09-21'),('23456789035','Amanda Souza',31,'1992-06-12'),('23456789046','Gabriela Lima',29,'1994-06-10'),('34567890122','Maria Santos',42,'1982-04-10'),('34567890123','Carla Castro',26,'1997-02-14'),('34567890134','Isabela Castro',27,'1996-12-20'),('34567890145','Henrique Castro',33,'1990-10-30'),('34567890156','Daniel Pereira',27,'1996-12-01'),('34567890167','Eduardo Silva',34,'1989-07-13'),('45678901233','Carlos Pereira',23,'2001-05-05'),('45678901234','Roberto Lima',30,'1993-03-18'),('45678901245','André Souza',31,'1992-01-08'),('45678901256','Letícia Lima',24,'1999-11-15'),('45678901267','Viviane Costa',33,'1991-03-22'),('45678901278','Camila Castro',27,'1996-08-22'),('56789012344','Fernanda Costa',31,'1993-06-25'),('56789012345','Luciana Oliveira',28,'1995-04-21'),('56789012356','Patrícia Lima',34,'1989-02-14'),('56789012357','Fernando Almeida',26,'1997-11-30'),('56789012368','Lúcia Almeida',38,'1985-09-18'),('67890123455','Rafael Almeida',27,'1996-07-12'),('67890123456','Gustavo Pereira',32,'1991-05-27'),('67890123467','Julio Oliveira',29,'1994-03-30'),('67890123478','Mariana Santos',32,'1991-07-19'),('67890123489','Robson Pereira',32,'1991-12-05'),('78901234566','Juliana Lima',29,'1994-08-19'),('78901234567','Sofia Santos',37,'1986-06-30'),('78901234578','Mariana Almeida',32,'1991-04-12'),('78901234579','Roberta Castro',28,'1995-04-07'),('78901234580','Larissa Oliveira',30,'1993-04-16'),('89012345677','Lucas Rodrigues',36,'1987-09-30'),('89012345678','Marcos Almeida',40,'1983-07-23'),('89012345680','Cláudia Silva',30,'1993-10-25'),('89012345689','Daniela Santos',35,'1988-05-18'),('89012345691','Marcelo Silva',26,'1997-06-01'),('90123456788','Beatriz Martins',33,'1990-10-22'),('90123456789','Aline Costa',29,'1994-08-17'),('90123456790','Rogério Rodrigues',27,'1996-06-24'),('90123456791','Thiago Martins',35,'1988-11-17'),('90123456792','Tatiane Costa',33,'1990-07-30');
/*!40000 ALTER TABLE `Pessoa` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-01 15:34:02

CREATE DATABASE  IF NOT EXISTS `minimundo` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `minimundo`;
-- MySQL dump 10.13  Distrib 8.0.36, for Linux (x86_64)
--
-- Host: localhost    Database: minimundo
-- ------------------------------------------------------
-- Server version	8.0.37-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Equipamento`
--

DROP TABLE IF EXISTS `Equipamento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Equipamento` (
  `ID_Equip` int NOT NULL AUTO_INCREMENT,
  `Tipo` varchar(50) NOT NULL,
  `Modelo` varchar(50) NOT NULL,
  `ID_Func` int NOT NULL,
  PRIMARY KEY (`ID_Equip`),
  KEY `ID_Func` (`ID_Func`),
  CONSTRAINT `Equipamento_ibfk_1` FOREIGN KEY (`ID_Func`) REFERENCES `Policial` (`ID_Func`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Equipamento`
--

LOCK TABLES `Equipamento` WRITE;
/*!40000 ALTER TABLE `Equipamento` DISABLE KEYS */;
INSERT INTO `Equipamento` VALUES (1,'Colete','Colete Balístico X1',11),(2,'Colete','Colete Balístico X2',12),(3,'Colete','Colete Tático V3',13),(4,'Colete','Colete Protetor Y4',14),(5,'Colete','Colete Anti-Impacto Z5',15),(6,'Colete','Colete Militar M6',16),(7,'Colete','Colete Urbano N7',17),(8,'Colete','Colete Anti-Furto O8',18),(9,'Colete','Colete Tático P9',19),(10,'Colete','Colete de Proteção Q10',20),(11,'Arma Branca','Faca Tática A1',11),(12,'Arma Branca','Porrete de Madeira B2',12),(13,'Arma Branca','Faca de Sobrevivência C3',13),(14,'Arma Branca','Cachimbo de Metal D4',14),(15,'Arma Branca','Facão E5',15),(16,'Arma Branca','Canivete Militar F6',16),(17,'Arma Branca','Porrete de Ferro G7',17),(18,'Arma Branca','Faca de Campo H8',18),(19,'Arma Branca','Espada de Treinamento I9',19),(20,'Arma Branca','Porrete Elétrico J10',20),(21,'Arma de Fogo','Pistola 9mm K1',11),(22,'Arma de Fogo','Revólver .38 L2',12),(23,'Arma de Fogo','Fuzil AR-15 M3',13),(24,'Arma de Fogo','Carabina de Assalto AK-47 N4',14),(25,'Arma de Fogo','Pistola .40 O5',15),(26,'Arma de Fogo','Rifle de Precisão P6',16),(27,'Arma de Fogo','Submetralhadora Uzi Q7',17),(28,'Arma de Fogo','Espingarda Remington R8',18),(29,'Arma de Fogo','Pistola Glock 17 S9',19),(30,'Arma de Fogo','Fuzil de Assalto F2000 T10',20);
/*!40000 ALTER TABLE `Equipamento` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `tr_InserirEquipamento` AFTER INSERT ON `Equipamento` FOR EACH ROW BEGIN
    IF NEW.Tipo IN ('Colete', 'Capacete', 'Escudo', 'Arma Branca', 'Arma de Fogo') THEN
		IF NEW.Tipo IN ('Colete', 'Capacete', 'Escudo') THEN
			IF NOT EXISTS (SELECT 1 FROM Equipamento_Protecao WHERE ID_Equip = NEW.ID_Equip) THEN
				INSERT INTO Equipamento_Protecao (ID_Equip)
				VALUES (NEW.ID_Equip);
			END IF;
		END IF;


        IF NEW.Tipo IN ('Arma Branca') THEN
			IF NOT EXISTS (SELECT 1 FROM Arma_Branca WHERE ID_Equip = NEW.ID_Equip) THEN
				INSERT INTO Arma_Branca (ID_Equip)
				VALUES (NEW.ID_Equip);
			END IF;
		END IF;
        
		IF NEW.Tipo IN ('Arma de Fogo') THEN
			IF NOT EXISTS (SELECT 1 FROM Arma_Fogo WHERE ID_Equip = NEW.ID_Equip) THEN
				INSERT INTO Arma_Fogo (ID_Equip)
				VALUES (NEW.ID_Equip);
			END IF;
		END IF;
        
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-03 22:36:26
